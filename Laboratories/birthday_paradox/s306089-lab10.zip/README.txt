all the code is in the script "birthday_paradox.py"

It doesn't take any parameters, and it will automatically call the two functions "run_average()" and "run_probability()" that will do the simulations of all the experiments and print the images of the results.
Uncomment the last line of the script to run also the extension, but it takes a long time to complete (5-6 hours)

The file "US_births_1994-2003_CDC_NCHS.csv" with the distribution of births is also included in order to make the script work