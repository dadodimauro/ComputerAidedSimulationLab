the script uses the following libraries:
- numpy
- math
- re
- pympler
- hashlib
- matplotlib

no imput parameters must be specified
make sure that both the script and the file "divina_commedia.txt" are in the same folder

N.B.
On a reasonably powerful machine the script takes 15-20 minutes to run due to the optional part done in the blom filter section